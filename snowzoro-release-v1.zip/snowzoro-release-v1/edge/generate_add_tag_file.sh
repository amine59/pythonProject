#!/bin/bash

db_sole=$1
file=$2
sql_file_path=$3
sed -i  '0,/TAG/{/TAG/d}' "$file"
while IFS= read -r line; do
  IFS="," read -a myarray <<< "${line}"
  # shellcheck disable=SC2001
  # shellcheck disable=SC2128
  tag_name=$(echo "${myarray}" | sed -e 's/^[[:space:]]*//')
  if  [ -z "${tag_name}" ] ; then
    exit 1
  else
    tag_name="'${tag_name}'"
  fi
  # shellcheck disable=SC2001
  tag_value=$(echo "${myarray[1]}" | sed -e 's/^[[:space:]]*//')
  if  [ -z "${tag_value}" ] ; then
    exit 1
  else
    tag_value="'${tag_value}'"
  fi
  # shellcheck disable=SC2001
  db_name=$(echo "${myarray[2]}" | sed -e 's/^[[:space:]]*//')
  if  [ -z "${db_name}" ] ; then
    exit 1
  else
    db_name="'${db_name}'"
  fi
  # shellcheck disable=SC2001
  schema_name=$(echo "${myarray[3]}" | sed -e 's/^[[:space:]]*//')
  if  [ -z "${schema_name}" ] ; then
    schema_name="NULL"
  else
    schema_name="'${schema_name}'"
  fi
  # shellcheck disable=SC2001
  table_name=$(echo "${myarray[4]}" | sed -e 's/^[[:space:]]*//')
  if  [ -z "${table_name}" ] ; then
      table_name="NULL"
  else
      table_name="'${table_name}'"
  fi
  # shellcheck disable=SC2001
  col_name=$(echo "${myarray[5]}" | sed -e 's/^[[:space:]]*//')
  if  [ -z "${col_name}" ] ; then
    col_name="NULL"
  else
    col_name="'${col_name}'"
  fi
  {
    echo "INSERT INTO ${db_sole}.SOCLE_SECURITY.OBJECT_TAG(TAG_NAME,TAG_VALUE,DB_NAME,SCHEMA_NAME,TABLE_NAME,COL_NAME) VALUES(${tag_name},${tag_value},${db_name},${schema_name},${table_name},${col_name});"
  } >> "$sql_file_path"
done < "$file"