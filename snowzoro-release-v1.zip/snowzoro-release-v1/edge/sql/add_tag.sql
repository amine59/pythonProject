USE ROLE SYSADMINTAG;
USE WAREHOUSE INGESTION_WH;
USE SCHEMA &socle_db.SOCLE_SECURITY;

CALL ADD_TAG('&tag_name','&tag_value','&database','&schema','&table','&column');