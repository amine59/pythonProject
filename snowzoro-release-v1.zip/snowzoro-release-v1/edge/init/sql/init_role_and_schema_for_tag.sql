use warehouse ADMIN_WH;

use role SYSADMIN;
CREATE SCHEMA IF NOT EXISTS &socle_db.SOCLE_SECURITY;

-- CREATE SYSADMIN TAG
use role SECURITYADMIN;

create role if not exists  SYSADMINTAG;
grant MANAGE GRANTS on account to role SYSADMINTAG;
grant USAGE on database &socle_db to role SYSADMINTAG;
grant USAGE,CREATE TABLE on schema &socle_db.socle_security to role SYSADMINTAG;

GRANT ROLE SYSADMINTAG TO USER &garden_user;
GRANT ROLE SYSADMINTAG TO ROLE "SG-APP-SNOWFLAKE-ADMIN";

grant usage on warehouse INGESTION_WH TO ROLE SYSADMINTAG;

-- GRANT ACCESS TO GOVERNANCE UI
use role ACCOUNTADMIN;
use database SNOWFLAKE;
GRANT DATABASE ROLE GOVERNANCE_VIEWER to role SYSADMIN;
GRANT DATABASE ROLE OBJECT_VIEWER to role SYSADMIN;
GRANT DATABASE ROLE GOVERNANCE_VIEWER to role SYSADMINTAG;
GRANT DATABASE ROLE OBJECT_VIEWER to role SYSADMINTAG;
--GRANT DATABASE ROLE GOVERNANCE_VIEWER to role "SG-APP-SNOWFLAKE-DATA-MGMT-SO";
--GRANT DATABASE ROLE OBJECT_VIEWER to role "SG-APP-SNOWFLAKE-DATA-MGMT-SO";

grant create masking policy on schema &socle_db.socle_security to role SYSADMINTAG;
grant create tag on schema &socle_db.socle_security to role SYSADMINTAG;

grant apply tag on account to role SYSADMINTAG;
grant apply masking policy on account to role SYSADMINTAG;

