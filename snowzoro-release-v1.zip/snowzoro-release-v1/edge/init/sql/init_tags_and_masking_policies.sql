USE ROLE SYSADMINTAG;
USE WAREHOUSE ADMIN_WH;
USE SCHEMA &socle_db.SOCLE_SECURITY;

CREATE tag IF NOT EXISTS DCP
ALLOWED_VALUES '0';
ALTER TAG DCP UNSET ALLOWED_VALUES;
ALTER TAG DCP
ADD ALLOWED_VALUES '0','1','2','3';

CREATE tag IF NOT EXISTS RISK_LEVEL
ALLOWED_VALUES '0';
ALTER TAG RISK_LEVEL UNSET ALLOWED_VALUES;
ALTER TAG RISK_LEVEL
ADD ALLOWED_VALUES '0','1','2','3','4';

create tag IF NOT EXISTS DATA_TYPE
ALLOWED_VALUES 'name';
ALTER TAG DATA_TYPE UNSET ALLOWED_VALUES;
ALTER TAG DATA_TYPE
ADD ALLOWED_VALUES 'name', 'email', 'id_cli', 'num_cpte', 'num_tel', 'id_dos','date_naiss', 'lieu_naiss', 'nom_indiv', 'prenom_indiv', 'cp_naiss', 'ident_indiv', 'ident_doss', 'ident_ctr_ext', 'num_poli_ass', 'num_crte_banc', 'num_cni', 'num_pass', 'num_cresid', 'ident_se', 'num_immat', 'num_rib', 'num_iban', 'num_cpt_banc', 'voie_adrss_indiv', 'num_siren', 'num_siret', 'adr_ip', 'num_ss', 'num_insee', 'champ_libre';

CREATE MASKING POLICY IF NOT EXISTS SOCLE_SECURITY.DCP_MASK_STRING AS (val string) returns string ->
  CASE
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP') = 0 THEN val
  ELSE '** DCP NOT QUALIFIED **'
END
EXEMPT_OTHER_POLICIES = TRUE;

ALTER MASKING POLICY SOCLE_SECURITY.DCP_MASK_STRING SET BODY ->
  CASE
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP') = 0 THEN val
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL') < 3 THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(role_name)=lower(current_role()) and MIN_DCP<=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(role_name)=lower(current_role()) and MAX_RISK_LEVEL>=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(partner_name)=lower(current_warehouse()) and lower(reader_account_id)=lower(current_account()) and MIN_DCP<=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(partner_name)=lower(current_warehouse()) and lower(reader_account_id)=lower(current_account()) and MAX_RISK_LEVEL>=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL')) THEN val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_tel' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_tel%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'email' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%email%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'name' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE  role_name=current_role() and LOWER(except) like '%name%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_indiv' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%ident_indiv%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_doss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%ident_doss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'lieu_naiss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%lieu_naiss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'date_naiss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%date_naiss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'nom_indiv' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%nom_indiv%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'prenom_indiv' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%prenom_indiv%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'cp_naiss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%cp_naiss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_ctr_ext' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%ident_ctr_ext%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_poli_ass' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_poli_ass%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_crte_banc' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_crte_banc%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_cni' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_cni%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_pass' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_pass%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_cresid' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_cresid%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_se' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%ident_se%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_immat' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_immat%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_rib' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_rib%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_iban' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_iban%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_cpt_banc' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_cpt_banc%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'voie_adrss_indiv' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%voie_adrss_indiv%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_siren' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_siren%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'nom_siret' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%nom_siret%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'adr_ip' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%adr_ip%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_ss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_ss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_insee' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_insee%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'champ_libre' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%champ_libre%') then val
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE') = 'email' THEN regexp_replace(val,'.+\@','*****@')
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) in ('nom_indiv', 'prenom_indiv', 'lieu_ness', 'voie_adrss_indiv','champ_libre') THEN '********'
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_tel' and startswith(val,'+') and contains(val, ' ') THEN concat(trim(substr(val,0,4)),' 99 99 99 99')
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_tel' and startswith(val,'+') THEN concat(trim(substr(val,0,4)),'99999999')
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_tel' and contains(val, ' ') THEN concat(trim(substr(val,0,3)),' 99 99 99 99')
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_tel' THEN concat(trim(substr(val,0,3)),'99999999')
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'cp_naiss' THEN concat(substr(val,0,2),'999')
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'date_naiss' THEN concat(substr(val,0,7),'-01')
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_indiv' THEN TO_VARCHAR(hash(val::NUMBER(11,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_doss' THEN TO_VARCHAR(hash(val::NUMBER(11,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_ctr_ext' THEN TO_VARCHAR(hash(val::NUMBER(20,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_poli_ass' THEN TO_VARCHAR(hash(val::NUMBER(20,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_crte_banc' THEN TO_VARCHAR(hash(val::NUMBER(16,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_cpt_banc' THEN TO_VARCHAR(hash(val::NUMBER(20,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_siren' THEN TO_VARCHAR(hash(val::NUMBER(9,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_siren' THEN TO_VARCHAR(hash(val::NUMBER(14,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_ss' THEN TO_VARCHAR(hash(val::NUMBER(15,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_insee' THEN TO_VARCHAR(hash(val::NUMBER(13,0)))
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'adr_ip' THEN '255.255.255.255'
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) in ('num_cni','num_pass','num_cresid','num_rib','num_iban','num_immat') THEN sha2(val)
  ELSE '** DCP NOT QUALIFIED **'
END;

CREATE MASKING POLICY IF NOT EXISTS SOCLE_SECURITY.DCP_MASK_NUMBER AS (val number) returns number ->
  CASE
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP') = 0 THEN val
    ELSE '999999999999'
  END
  EXEMPT_OTHER_POLICIES = true;

ALTER MASKING POLICY SOCLE_SECURITY.DCP_MASK_NUMBER SET BODY ->
  CASE
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP') = 0 THEN val
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL') < 3 THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(role_name)=lower(current_role()) and MIN_DCP<=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(role_name)=lower(current_role()) and MAX_RISK_LEVEL>=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(partner_name)=lower(current_warehouse()) and lower(reader_account_id)=lower(current_account()) and MIN_DCP<=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(partner_name)=lower(current_warehouse()) and lower(reader_account_id)=lower(current_account()) and MAX_RISK_LEVEL>=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL')) THEN val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_indiv' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%ident_indiv%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_doss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%ident_doss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'ident_ctr_ext' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%ident_ctr_ext%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_poli_ass' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_poli_ass%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_crte_banc' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_crte_banc%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'cp_naiss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%cp_naiss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_cpt_banc' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_cpt_banc%') then val
     WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_tel' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_tel%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_siren' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_siren%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_siret' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_siret%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_ss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_ss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_insee' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%num_insee%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'cp_naiss' THEN concat(substr(to_varchar(val),0,2),'999')::NUMBER(5,0)
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) in('ident_indiv', 'ident_doss', 'ident_ctr_ext', 'num_poli_ass', 'num_crte_banc', 'num_cpt_banc', 'num_siren', 'num_siret', 'num_ss', 'num_insee')  THEN hash(val)
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'num_tel' THEN concat(trim(substr(to_varchar(val),0,3)),'99999999')::NUMBER(12,0)
    ELSE '999999999999'
  END;

CREATE MASKING POLICY IF NOT EXISTS SOCLE_SECURITY.DCP_MASK_DATE AS (val date) returns date ->
  CASE
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP') = 0 THEN val
    ELSE current_date()
  END
  EXEMPT_OTHER_POLICIES = true;

ALTER MASKING POLICY SOCLE_SECURITY.DCP_MASK_DATE SET BODY ->
  CASE
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP') = 0 THEN val
    WHEN SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL') < 3 THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(role_name)=lower(current_role()) and MIN_DCP<=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(role_name)=lower(current_role()) and MAX_RISK_LEVEL>=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(partner_name)=lower(current_warehouse()) and lower(reader_account_id)=lower(current_account()) and MIN_DCP<=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DCP')) THEN val
    WHEN exists(SELECT ROLE_NAME FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE lower(partner_name)=lower(current_warehouse()) and lower(reader_account_id)=lower(current_account()) and MAX_RISK_LEVEL>=SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.RISK_LEVEL')) THEN val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'date_naiss' and exists(select role_name  FROM &socle_db.SOCLE_SECURITY.MAT_ROLE_DCP WHERE role_name=current_role() and LOWER(except) like '%date_naiss%') then val
    WHEN lower(SYSTEM$GET_TAG_ON_CURRENT_COLUMN('&socle_db.SOCLE_SECURITY.DATA_TYPE')) = 'date_naiss' THEN DATE_TRUNC('MONTH', val)
    ELSE current_date()
  END;

alter tag DCP SET MASKING POLICY DCP_MASK_STRING FORCE;
alter tag DCP SET MASKING POLICY DCP_MASK_NUMBER FORCE;
alter tag DCP SET MASKING POLICY DCP_MASK_DATE FORCE;
alter tag RISK_LEVEL SET MASKING POLICY DCP_MASK_STRING FORCE;
alter tag RISK_LEVEL SET MASKING POLICY DCP_MASK_NUMBER FORCE;
alter tag RISK_LEVEL SET MASKING POLICY DCP_MASK_DATE FORCE;