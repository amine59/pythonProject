use role SYSADMINTAG;
USE WAREHOUSE ADMIN_WH;
USE SCHEMA &socle_db.SOCLE_SECURITY;

CREATE OR REPLACE PROCEDURE &socle_db.SOCLE_SECURITY.INIT_TAG(object_tag_table STRING)
  RETURNS TABLE(TAG_NAME VARCHAR, DB_NAME VARCHAR, SCHEMA_NAME VARCHAR, TABLE_NAME VARCHAR, COL_NAME VARCHAR, STATUS VARCHAR)
  LANGUAGE PYTHON
  RUNTIME_VERSION = 3.10
  HANDLER = 'main'
  PACKAGES = ('snowflake-snowpark-python', 'joblib')
  EXECUTE AS CALLER
AS $$
import snowflake.snowpark as snowpark

def main(session, object_tag_table):
    dataframe = session.table(object_tag_table)
    result = session.create_dataframe(data=[[None,None,None,None,None,None]], schema=['TAG_NAME','DB_NAME','SCHEMA_NAME','TABLE_NAME', 'COL_NAME' ,'STATUS'])
    for row in dataframe.collect():
        try:
            if row['DB_NAME'] != None:
                if row['SCHEMA_NAME'] != None :
                    if row['TABLE_NAME'] != None :
                        target_table = row['DB_NAME'] + '.' + row['SCHEMA_NAME'] + '.' + row['TABLE_NAME']
                        if row['COL_NAME'] != None :

                            session.sql("ALTER TABLE IF EXISTS " + target_table + " MODIFY COLUMN " + row['COL_NAME'] +" set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                        else:
                            session.sql("ALTER TABLE IF EXISTS " + target_table + " set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                    else:
                        target_schema = row['DB_NAME'] + '.' + row['SCHEMA_NAME']
                        session.sql("ALTER SCHEMA IF EXISTS " + target_schema + " set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                else:
                    session.sql("ALTER DATABASE IF EXISTS " + row['DB_NAME'] + " set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                result = result.union(session.create_dataframe([[row['TAG_NAME'],row['DB_NAME'],row['SCHEMA_NAME'],row['TABLE_NAME'],row['COL_NAME'],'ADDED']], schema=['TAG_NAME','DB_NAME','SCHEMA_NAME','TABLE_NAME','STATUS']))
        except:
            print('failed')
            result = result.union_all(session.create_dataframe([[row['TAG_NAME'],row['DB_NAME'],row['SCHEMA_NAME'],row['TABLE_NAME'],row['COL_NAME'],'FAILED']], schema=['TAG_NAME','DB_NAME','SCHEMA_NAME','TABLE_NAME','COL_NAME','STATUS']))
    return result.dropna(how='all')
$$;

CREATE OR REPLACE PROCEDURE &socle_db.SOCLE_SECURITY.UPDATE_TAG(object_tag_table_stream STRING)
  RETURNS TABLE(TAG_NAME VARCHAR, DB_NAME VARCHAR, SCHEMA_NAME VARCHAR, TABLE_NAME VARCHAR, COL_NAME VARCHAR, STATUS VARCHAR)
  LANGUAGE PYTHON
  RUNTIME_VERSION = 3.10
  HANDLER = 'main'
  PACKAGES = ('snowflake-snowpark-python')
  EXECUTE AS CALLER
AS $$
import snowflake.snowpark as snowpark

def main(session, object_tag_table_stream):

    temporary_table = '&socle_db.socle_security.object_tag_tmp'
    session.sql("CREATE OR REPLACE TEMPORARY TABLE "+ temporary_table +" AS select * from " + object_tag_table_stream + ";").collect()
    dataframe = session.table(temporary_table)
    result = session.create_dataframe(data=[[None,None,None,None,None,None]], schema=['TAG_NAME','DB_NAME','SCHEMA_NAME','TABLE_NAME', 'COL_NAME' ,'STATUS'])
    for row in dataframe.collect():
        try:
            if row['DB_NAME'] != None:
                if row['SCHEMA_NAME'] != None :
                    if row['TABLE_NAME'] != None :
                        target_table = row['DB_NAME'] + '.' + row['SCHEMA_NAME'] + '.' + row['TABLE_NAME']
                        if row['COL_NAME'] != None :
                            if str.upper(row['METADATA$ACTION']) == 'INSERT' or str.upper(row['METADATA$ACTION']) == 'UPDATE':
                                session.sql("ALTER TABLE IF EXISTS " + target_table + " MODIFY COLUMN " + row['COL_NAME'] +" set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                            else:
                                session.sql("ALTER TABLE IF EXISTS " + target_table + " MODIFY COLUMN " + row['COL_NAME'] +" unset tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] + "; ").collect()
                        else:
                            if str.upper(row['METADATA$ACTION']) == 'INSERT' or str.upper(row['METADATA$ACTION']) == 'UPDATE':
                                session.sql("ALTER TABLE IF EXISTS " + target_table + " set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                            else:
                                session.sql("ALTER TABLE IF EXISTS " + target_table + " unset tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +"; ").collect()
                    else:
                        target_schema = row['DB_NAME'] + '.' + row['SCHEMA_NAME']
                        if str.upper(row['METADATA$ACTION']) == 'INSERT' or str.upper(row['METADATA$ACTION']) == 'UPDATE':
                            session.sql("ALTER SCHEMA IF EXISTS " + target_schema + " set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                        else:
                            session.sql("ALTER SCHEMA IF EXISTS " + target_schema + " unset tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +"; ").collect()
                else:
                    if str.upper(row['METADATA$ACTION']) == 'INSERT' or str.upper(row['METADATA$ACTION']) == 'UPDATE':
                        session.sql("ALTER DATABASE IF EXISTS " + row['DB_NAME'] + " set tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME'] +" = '"+row['TAG_VALUE'] +"'; ").collect()
                    else:
                       session.sql("ALTER DATABASE IF EXISTS " + row['DB_NAME'] + " unset tag &socle_db.SOCLE_SECURITY."+ row['TAG_NAME']+"; ").collect()
                print("good")
                result = result.union(session.create_dataframe([[row['TAG_NAME'],row['DB_NAME'],row['SCHEMA_NAME'],row['TABLE_NAME'],row['COL_NAME'],row['METADATA$ACTION']]], schema=['TAG_NAME','DB_NAME','SCHEMA_NAME','TABLE_NAME','STATUS']))
        except:
            print('failed')
            result = result.union_all(session.create_dataframe([[row['TAG_NAME'],row['DB_NAME'],row['SCHEMA_NAME'],row['TABLE_NAME'],row['COL_NAME'],'FAILED']], schema=['TAG_NAME','DB_NAME','SCHEMA_NAME','TABLE_NAME','COL_NAME','STATUS']))
    return result.dropna(how='all')
$$;

CREATE OR REPLACE PROCEDURE &socle_db.SOCLE_SECURITY.MERGE_AND_INIT_TAG(object_tag_table STRING ,object_tag_table_stream STRING)
  RETURNS TABLE(TAG_NAME VARCHAR, DB_NAME VARCHAR, SCHEMA_NAME VARCHAR, TABLE_NAME VARCHAR, COL_NAME VARCHAR, STATUS VARCHAR)
  LANGUAGE PYTHON
  RUNTIME_VERSION = 3.10
  HANDLER = 'main'
  PACKAGES = ('snowflake-snowpark-python')
  EXECUTE AS CALLER
AS $$
import snowflake.snowpark as snowpark

def main(session, object_tag_table, object_tag_table_stream):

    temporary_table = '&socle_db.socle_security.object_tag_tmp'
    session.sql("CREATE OR REPLACE TEMPORARY TABLE " + temporary_table + " AS SELECT DISTINCT * FROM " + object_tag_table + ";").collect()
    session.sql("merge into "+ temporary_table +" as t1 using SNOWFLAKE.account_usage.tag_references as t2 on upper(t1.TAG_NAME) = upper(t2.TAG_NAME) AND upper(t1.DB_NAME) = upper(t2.OBJECT_DATABASE) AND upper(t1.SCHEMA_NAME) = upper(t2.OBJECT_SCHEMA) AND upper(t1.TABLE_NAME) = upper(t2.OBJECT_NAME) AND upper(t1.COL_NAME) = upper(t2.COLUMN_NAME) AND TAG_SCHEMA = 'SOCLE_SECURITY' WHEN MATCHED AND upper(t1.TAG_VALUE) <> upper(t2.TAG_VALUE) THEN UPDATE set t1.TAG_VALUE = t2.TAG_VALUE WHEN NOT MATCHED AND TAG_SCHEMA = 'SOCLE_SECURITY' THEN INSERT (TAG_NAME, TAG_VALUE, DB_NAME, SCHEMA_NAME, TABLE_NAME, COL_NAME) VALUES (TAG_NAME, TAG_VALUE, OBJECT_DATABASE, OBJECT_SCHEMA, OBJECT_NAME, COLUMN_NAME);").collect()
    session.sql("TRUNCATE TABLE " + object_tag_table + ";").collect()
    session.sql("INSERT INTO " + object_tag_table + " SELECT * FROM " + temporary_table + ";").collect()
    result = session.createDataFrame(session.sql("CALL SOCLE_SECURITY.INIT_TAG('" + object_tag_table + "');").collect())
    session.sql("CREATE OR REPLACE TEMPORARY TABLE "+ temporary_table +" AS select * from " + object_tag_table_stream + ";").collect()
    print("all good")
    return result;
$$;

CREATE OR REPLACE PROCEDURE &socle_db.SOCLE_SECURITY.ADD_TAG(TAG_NAME VARCHAR, TAG_VALUE VARCHAR, DB_NAME VARCHAR, SCHEMA_NAME VARCHAR, TABLE_NAME VARCHAR, COL_NAME VARCHAR)
  RETURNS TABLE(STATUS VARCHAR, MESSAGE VARCHAR)
  LANGUAGE PYTHON
  RUNTIME_VERSION = 3.10
  HANDLER = 'main'
  PACKAGES = ('snowflake-snowpark-python')
  EXECUTE AS CALLER
AS $$
import snowflake.snowpark as snowpark

def main(session: snowpark.Session, tag_name, tag_value, db_name,schema_name, table_name, col_name):

    object_tag_table = '&socle_db.socle_security.object_tag'
    object_tag_table_stream = '&socle_db.socle_security.object_tag_stream'

    if (tag_name == None or tag_name.strip() == "") or (tag_value == None or tag_value.strip() == "") or (db_name == None or db_name.strip() == ""):
        return session.create_dataframe(data=[["FAILED","MISSING MANDATORY PARAMETERS (tag_name, tag_value, database_name"]], schema=['STATUS','MESSAGE'])
    else:
        tag_name = "'" + tag_name + "'"
        tag_value = "'" + tag_value + "'"
        db_name = "'" + db_name + "'"

    if schema_name == None or schema_name.strip() == "" or schema_name == "NULL":
        schema_name = "NULL"
    else:
        schema_name = "'" + schema_name + "'"
    if table_name == None or table_name.strip() == "" or table_name == "NULL":
        table_name = "NULL"
    else:
        table_name = "'" + table_name + "'"
    if col_name == None or col_name.strip() == "" or col_name == "NULL":
        col_name = "NULL"
    else:
        col_name = "'" + col_name + "'"
    session.sql("INSERT INTO " + object_tag_table + "(TAG_NAME, TAG_VALUE, DB_NAME, SCHEMA_NAME, TABLE_NAME, COL_NAME) VALUES(" + tag_name + ", " + tag_value + ", " + db_name +", " + schema_name +", " + table_name +", " + col_name  +");").collect()
    session.sql("CALL SOCLE_SECURITY.UPDATE_TAG('" + object_tag_table_stream + "')").collect()
    result = session.create_dataframe(data=[["SUCCESS","TAG ADDED"]], schema=['STATUS','MESSAGE'])
    print("all good")
    return result
$$;

CREATE TASK IF NOT EXISTS &socle_db.SOCLE_SECURITY.MERGE_AND_INIT_TAG
WAREHOUSE = 'ADMIN_WH'
SCHEDULE = 'USING CRON 9 0 * * * Europe/Paris'
AS
CALL &socle_db.SOCLE_SECURITY.MERGE_AND_INIT_TAG('&socle_db.SOCLE_SECURITY.OBJECT_TAG', '&socle_db.SOCLE_SECURITY.OBJECT_TAG_STREAM');
ALTER TASK  &socle_db.SOCLE_SECURITY.MERGE_AND_INIT_TAG RESUME;