#!/bin/bash

all_sources=/app/list/data/factory/fr/app/usage/socdb/processing/batch
tag="SNOWZORO_DEPLOY_ROLE_AND_SCHEMA_FOR_TAG"
source $all_sources/snowmonitor/CURRENT/snow_shell_log.sh $tag
source $all_sources/snowgarden/CURRENT/edge_env.sh
source $all_sources/snowgarden/CURRENT/snow_env.sh "${env}"

func_INFO "SNOWZORO : DEPLOY ROLE AND SCHEMA FOR TAG"
func_INFO "Ce programme a besoin d'un user snowflake avec le role ACCOUNTADMIN"
echo -n Snowuser:
read snowuser
echo -n Password:
read -s password
echo

BASEDIR=$(dirname "$0")
warehouse="INGESTION_WH"
log_level="DEBUG"


if [ -z "${socdbso}" ] ; then
	func_ERREUR "le parametre socdbso n'est pas d�fini" -r 1 -t $tag
fi
if [ -z "${socdbcl}" ] ; then
	func_ERREUR "le parametre socdbcl n'est pas d�fini" -r 1 -t $tag
fi
if [ -z "${socdbca}" ] ; then
	func_ERREUR "le parametre socdbca n'est pas d�fini" -r 1 -t $tag
fi
if [ -z "${socdbfr}" ] ; then
	func_ERREUR "le parametre socdbfr n'est pas d�fini" -r 1 -t $tag
fi

env_upper="$(echo "$env" | tr '[:lower:]' '[:upper:]')"
socle_database="${env_upper}_SOCLE"

sh $all_sources/snowexecutor/CURRENT/snow_script_executor.sh -t "${tag}" \
  -u "${snowuser}" -p "${password}" -r "ACCOUNTADMIN" -w $warehouse \
  -s "$BASEDIR/sql/init_role_and_schema_for_tag.sql" \
  -v socle_db "${socle_database}" \
  -log_level $log_level
return_code=$?
exit $return_code
