#!/bin/bash

all_sources=/app/list/data/factory/fr/app/usage/socdb/processing/batch
tmp_dir=/app/list/data/tmp
tag="SNOWZORO_ADD_TAG"
source $all_sources/snowmonitor/CURRENT/snow_shell_log.sh $tag
source $all_sources/snowgarden/CURRENT/edge_env.sh
source $all_sources/snowgarden/CURRENT/snow_env.sh "${env}"

while [[ $# -gt 0 ]]; do
  case $1 in
    -d|--database)
      database="$2"
      shift # past argument
      shift # past value
      ;;
	-sc|--schema)
      schema="$2"
      shift # past argument
      shift # past value
      ;;
	-t|--table)
      table="$2"
      shift # past argument
      shift # past value
      ;;
  -c|--column)
      column="$2"
      shift # past argument
      shift # past value
      ;;
  -f|--csv_file)
      file="$2"
      shift # past argument
      shift # past value
      ;;
    -tn|--tag-name)
        tag_name="$2"
        shift # past argument
        shift # past value
        ;;
    -tv|--tag_value)
        tag_value="$2"
        shift # past argument
        shift # past value
        ;;
    *)
      POSITIONAL_ARGS+=("$1") # save positional arg
      shift # past argument
      ;;
  esac
done

func_INFO "SNOWZORO : ADD TAG"
func_INFO "Ce programme a besoin d'un user snowflake avec le role SYSADMINTAG"
echo -n Snowuser:
read snowuser
echo -n Password:
read -s password
echo

if [ -z "${tag_name}" ] && [ -z "${file}"  ] ; then
	func_ERREUR "le nom du tag doit être specifié" -r 6 -t "${tag}"
	exit 6
fi

if [ -z "${tag_value}" ] && [ -z "${file}"  ] ; then
	func_ERREUR "la valeur du tag doit etre specifie" -r 6 -t "${tag}"
	exit 6
fi

if [ -z "${database}" ] && [ -z "${file}"  ] ; then
	func_ERREUR "la valeur du tag doit etre specifie" -r 6 -t "${tag}"
	exit 6
fi

if [ -z "${schema}" ] ; then
  schema="NULL"
fi

if [ -z "${table}" ] ; then
  table="NULL"
fi

if [ -z "${column}" ] ; then
  column="NULL"
fi

BASEDIR=$(dirname "$0")
warehouse="INGESTION_WH"
log_level="DEBUG"


if [ -z "${socdbso}" ] ; then
	func_ERREUR "le parametre socdbso n'est pas d�fini" -r 1 -t $tag
fi
if [ -z "${socdbcl}" ] ; then
	func_ERREUR "le parametre socdbcl n'est pas d�fini" -r 1 -t $tag
fi
if [ -z "${socdbca}" ] ; then
	func_ERREUR "le parametre socdbca n'est pas d�fini" -r 1 -t $tag
fi
if [ -z "${socdbfr}" ] ; then
	func_ERREUR "le parametre socdbfr n'est pas d�fini" -r 1 -t $tag
fi

env_upper="$(echo "$env" | tr '[:lower:]' '[:upper:]')"
socle_db="${env_upper}_socle"
return_code=1
if [ -z "${file}" ] ; then
  sh $all_sources/snowexecutor/CURRENT/snow_script_executor.sh -t "${tag}" \
    -u "${snowuser}" -p "${password}" -r "SYSADMINTAG" -w $warehouse \
    -s "$BASEDIR/sql/add_tag.sql" \
    -v socle_db "${socle_db}" \
    -v tag_name "${tag_name}" \
    -v tag_value "${tag_value}" \
    -v database "${database}" \
    -v schema "${schema}" \
    -v table "${table}" \
    -v column "${column}" \
    -log_level $log_level
  return_code=$?
else
  tmp_sql_file_path="${tmp_dir}/add_tag.sql"
  touch "${tmp_sql_file_path}"
  {
    echo "USE WAREHOUSE INGESTION_WH;"
    echo "USE ROLE SYSADMINTAG;"
    echo "USE SCHEMA ${socle_db}.SOCLE_SECURITY;"
  } > "${tmp_sql_file_path}"
  if $BASEDIR/generate_add_tag_file.sh "${socle_db}" "${file}" "${tmp_sql_file_path}" ; then
    echo "CALL UPDATE_TAG('${socle_db}.SOCLE_SECURITY.OBJECT_TAG_STREAM');" >> "${tmp_sql_file_path}"
    sh $all_sources/snowexecutor/CURRENT/snow_script_executor.sh -t "${tag}" \
      -u "${snowuser}" -p "${password}" -r "SYSADMIN" -w $warehouse \
      -s "${tmp_sql_file_path}" \
      -log_level $log_level
    return_code=$?
    rm "${tmp_sql_file_path}"
  else
    func_ERREUR "le fichier csv est mal formaté" -r 1 -t $tag
    exit 6
  fi

fi
exit $return_code
