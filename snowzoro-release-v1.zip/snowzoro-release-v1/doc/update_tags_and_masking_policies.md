# UPDATE TAGS AND MASKING POLICIES

## Objectifs
* le but du script est de mettre à jour les Tag et les Masking Policies
## dépendances :
* snowexecutor
* snowmonitor
* snowgarden (snow_env et edge_env)

## Parametres :

## Codes retours :
* 1|2 : anomalie dans les parametres de snowsql ou avec le client
* 3|4 : anomalie de connexion avec le serveur snowflake
* 5 : erreur sql
* 6 : erreur dans les parametres

## Usage :
    update_tags_and_masking_policies.sh

## Procedure de mise à jour des valeurs d'un tag : 
1. Dans le fichier [init_tags_and_masking_policies.sql](../edge/init/sql/init_tags_and_masking_policies.sql)
2. Modifier la valeur des **ALLOWED_VALUES** dans la partie **ALTER** du tag et **non dans le CREATE**
3. Commit and push
4. Lancer le script une fois par monde

## Procedure de mise à jour d'une masking policy :
1. Dans le fichier [init_tags_and_masking_policies.sql](../edge/init/sql/init_tags_and_masking_policies.sql)
2. Modifier la policy dans la partie **ALTER MASKING POLICY** et **non dans le CREATE MASKING POLICY**
3. Commit and push
4. Lancer le script une fois par monde


## Log :
Les logs sont collectés via le snowmonitor et donc retrouvable dans Elisa