# DEPLOY ROLE AND SCHEMA for TAG

## Objectifs
* le but du script est de déployer le schéma qui contiendra les tags et le role permettant de manager les tags et les masking policy
## dépendances :
* snowexecutor
* snowmonitor
* snowgarden (snow_env et edge_env)

## Parametres :

:warning: il faut un role **ACCOUNTADMIN** pour utiliser le script

## Codes retours :
* 1|2 : anomalie dans les parametres de snowsql ou avec le client
* 3|4 : anomalie de connexion avec le serveur snowflake
* 5 : erreur sql
* 6 : erreur dans les parametres

## Usage :
    deploy_role_and_schema_for_tag.sh

## Composants déployés
* le schéma **SOCLE_SECURITY** qui contient Tag, Masking Policy et Row Policy
* Le role **SYSADMINTAG** qui permet de manager les Tag, Masking Policy et Row Policy

## Log :
Les logs sont collectés via le snowmonitor et donc retrouvable dans Elisa
