# DEPLOY TAGS MASKING POLCIES AND MANAGE PROCEDURES

## Objectifs
* le but du script est de déployer les tags, les masking policy associées et les composants nécessaires à leur opération 
## dépendances :
* snowexecutor
* snowmonitor
* snowgarden (snow_env et edge_env)

## Paramètres :

## Codes retours :
* 1|2 : anomalie dans les parametres de snowsql ou avec le client
* 3|4 : anomalie de connexion avec le serveur snowflake
* 5 : erreur sql
* 6 : erreur dans les parametres

## Usage :
    deploy_tags_masking_policies_and_management_proc.sh

## Scripts SQL et composants déployés : 
* [init_table_and_streams_for_tag](edge/init/sql/init_table_and_streams_for_tag.sql) qui déploie :
  * La table **MAT_ROLE_DCP** qui contient la matrice des rôles permettant de savoir quel rôle peut accéder à quelle DCP
  * La table **OBJECT_TABLE** qui contient un miroir de l'ensemble des objets sql tagués
  * Le stream **OBJECT_TABLE_STREAM** qui est un stream sur la table **OBJECT_TABLE**
* [init_tags_and_masking_policies.sql](edge/init/sql/init_tags_and_masking_policies.sql) qui déploie :
    * Les TAGS **DCP** et **DCP_TYPE**
    * Les Masking Policy **DCP_MASK_STRING** et **DCP_MASK_NUMBER**
* [init_deploy_store_procedure_for_tag](edge/init/sql/init_deploy_store_procedure_for_tag.sql) qui déploie les procédures suivantes :
    * **INIT_TAG** qui applique les tags de l'ensemble de la table **OBJECT_TAG**
    * **UPDATE_TAG** qui applique les modifications des tags présents dans le stream
    * **MERGE_AND_INIT_TAG** Merge les tags présents dans snowflake avec la table **OBJECT_TAG** et lance **INIT_TAG**
    * **ADD_TAG** permet d'ajouter un tag à un objet SQL
## Log :
Les logs sont collectés via le snowmonitor et donc retrouvable dans Elisa