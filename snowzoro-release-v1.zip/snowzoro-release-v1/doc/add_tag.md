# ADD Tag

## Objectifs
* le but du script est d'ajouter un ou un ensemble de tag à un ou un ensemble d'objet SQL (Database, Schema, Table)
## dépendances :
* snowexecutor
* snowmonitor
* snowgarden (snow_env et edge_env)

## Parametres :
* add_tag.sh
* -tn --tag-name tag_name
* -tv --tag_value tag_value
* (-d --database database [-sc --schema schema -t --table table -c --column colonne] (optionnel) | -f --csv-file csv_file_path)

Cas spécifique : 
* Si uniquement la base est spécifié, le tag sera appliqué sur la base de donnée
* Si uniquement la base et le schéma sont spécifiés, le tag sera appliqué sur le schéma
* Si uniquement la base, le schéma et la table sont spécifiés, le tag sera appliqué sur la table

## Codes retours :
* 1|2 : anomalie dans les parametres de snowsql ou avec le client
* 3|4 : anomalie de connexion avec le serveur snowflake
* 5 : erreur sql
* 6 : erreur dans les parametres

## Usage :
    add_tag.sh -tn $tag_name -tv $tag_value -d $database [-sc $schema -t $table -c $colonne]
    add_tag.sh -tn DCP -tv 2 -d TEST -sc TEST_WDX -t RAW_FAKE_PEOPLE -c NAME

    add_tag.sh -f $csv_file
    add_tag.sh -f /home/svcdevso/wdx/test

## Format du fichier csv :
* c'est un fichier csv permettant d'ajouter de façon massive des tags à des objets SQL
* Format : TAG_NAME,TAG_VALUE,DATABASE,[SCHEMA],[TABLE],[COLONNE]
* exemple : DCP,2,TEST,TEST_WDX,RAW_FAKE_PEOPLE,NAME

## Log :
Les logs sont collectés via le snowmonitor et donc retrouvable dans Elisa
