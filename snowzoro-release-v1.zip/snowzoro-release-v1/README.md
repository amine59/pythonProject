# SnowZoro
## Objectifs
SnowZoro est un outil permettant d'industrialiser la gestion des tags et des masking policy dans Snowflake, principalement ceux liés à la DCP

Capacités :
* Déployer et modifier les tags DCP et DCP Type ainsi que leurs valeurs autorisées
* Déployer et mettre à jour les masking policy appliqué sur le tag DCP
* Déployer les UDF permettant de facilement appliquer les tags sur les objets
* Déployer et mettre à jour la matrice de role DCP qui permet de référencer les rôles ayant accès à de la DCP
* Déployer ou supprimer un tag sur un object (Base de données, Schéma, Table, Colonne)

## Initialisation du compte avant d'utiliser l'outil ou les tags sur un compte
Pour pouvoir utiliser les tags et le masking policy de façon à gérer la DCP de façon efficace, il faut déployer un certain nombre de ressources contenu dans des scripts : 
* Le script [deploy_role_and_schema_for_tag](doc/deploy_role_and_schema_for_tag.md) permet de déployer le script sql : 
  * [init_role_and_schema_for_tag.sql](edge/init/sql/init_role_and_schema_for_tag.sql) qui déploie : 
    * Le Schéma **SOCLE_SECURITY** qui contient l'ensemble des tags, masking policy, row policy pour un compte
    * Le Rôle **SYSADMINTAG** qui permet de gérer les tags sans être ACCOUNTADMIN
* Le script [deploy_tags_masking_policies_and_management_proc](doc/deploy_tags_masking_policies_and_management_proc.md) permet de deployer les scripts sql : 
  * [init_table_and_streams_for_tag](edge/init/sql/init_table_and_streams_for_tag.sql) qui déploie : 
    * La table **MAT_ROLE_DCP** qui contient la matrice des rôles permettant de savoir quel rôle peut accéder à quelle DCP 
    * La table **OBJECT_TABLE** qui contient un miroir de l'ensemble des objets sql tagués
    * Le stream **OBJECT_TABLE_STREAM** qui est un stream sur la table **OBJECT_TABLE**
  * [init_tags_and_masking_policies.sql](edge/init/sql/init_tags_and_masking_policies.sql) qui déploie : 
    * Les TAGS **DCP** et **DCP_TYPE**
    * Les Masking Policy **DCP_MASK_STRING** et **DCP_MASK_NUMBER**
  * [init_deploy_store_procedure_for_tag](edge/init/sql/init_deploy_store_procedure_for_tag.sql) qui déploie les procédures suivantes : 
    * **INIT_TAG** qui applique les tags de l'ensemble de la table **OBJECT_TAG**
    * **UPDATE_TAG** qui applique les modifications des tags présents dans le stream
    * **MERGE_AND_INIT_TAG** Merge les tags présents dans snowflake avec la table **OBJECT_TAG** et lance **INIT_TAG**
    * **ADD_TAG** permet d'ajouter un tag à un objet SQL

## Modification des Tag et des Masking Policy
Le script [update_tags_and_masking_policies](doc/update_tags_and_masking_policies.md) permet d'appliquer les modifications faites sur les tags et les masking policy
afin d'être iso sur l'ensemble des comptes

## Ajout de tag
Le script [add_tag](doc/add_tag.md) permet d'ajouter de façon unitaire ou de façon massive des tags sur un ensemble d'objet SQL

